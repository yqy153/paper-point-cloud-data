import geopandas as gpd
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
from shapely.geometry import LineString
import numpy as np

# 读取Shapefile文件
def read_shapefile(file_path):
    return gpd.read_file(file_path)

# 对等高线进行平滑处理
def smooth_contour_lines(contour_lines, num_points=100):
    smoothed_lines = []
    for line in contour_lines.geometry:
        # Extract x, y values from LineString
        x, y = line.xy

        # Remove duplicate x values
        unique_x, unique_idx = np.unique(x, return_index=True)
        unique_y = np.take(y, unique_idx)

        # Interpolate smoothed curve
        f = interp1d(unique_x, unique_y, kind='cubic')
        x_smooth = np.linspace(min(unique_x), max(unique_x), num_points)
        y_smooth = f(x_smooth)

        # Create smoothed LineString
        smoothed_line = LineString(zip(x_smooth, y_smooth))
        smoothed_lines.append(gpd.GeoSeries(geometry=[smoothed_line]))

    return gpd.GeoDataFrame(geometry=smoothed_lines)
# 可视化平滑后的等高线
def visualize_contour_lines(contour_lines, smoothed_contour_lines):
    fig, ax = plt.subplots()
    contour_lines.plot(ax=ax, color='blue', label='Original Contour Lines')
    smoothed_contour_lines.plot(ax=ax, color='red', linestyle='dashed', label='Smoothed Contour Lines')
    plt.title('Contour Lines and Smoothed Contour Lines')
    plt.xlabel('X-axis')
    plt.ylabel('Y-axis')
    plt.legend()
    plt.grid(True)
    plt.show()

# 保存平滑后的等高线到Shapefile文件
def save_contour_lines_to_shapefile(smoothed_lines, output_file):
    smoothed_lines.to_file(output_file)

# 主程序
shp_file_path = 'D:/XY/20240130/920_step4.6.dxf'
output_shp_file = 'D:/XY/20240130/920_step4.6_smooth.dxf'

contour_lines = read_shapefile(shp_file_path)
smoothed_contour_lines = smooth_contour_lines(contour_lines)
visualize_contour_lines(contour_lines, smoothed_contour_lines)
save_contour_lines_to_shapefile(smoothed_contour_lines, output_shp_file)
