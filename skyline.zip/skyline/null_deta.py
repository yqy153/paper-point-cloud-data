import numpy as np
import os

def null_deta(TLS, ALS, a, b, cells_data_ALS_no0, save_path, EDS, MDS):
    e_D_sum = 0
    m_D_sum = 0
    for i in range(3, 15):
        # 空仓比例判断
        esd_deta = []
        esd_deta = TLS[TLS[:, 0] == i][:, 8] - ALS[ALS[:, 0] == i][:, 8] # 高程标准差
        me_deta = TLS[TLS[:, 0] == i][:, 9] - ALS[ALS[:, 0] == i][:, 9] # 最大高程
        e_D = np.abs(esd_deta[1])
        m_D = np.abs(me_deta[1])
        # TLS与ALS的20个圆环的高程标准差的差值之和和最大高程差值之和小于10m
        e_D_sum = e_D_sum + e_D
        m_D_sum = m_D_sum + m_D
        if e_D_sum > EDS or m_D_sum > MDS:  # 每个点处and m_D_sum > 50 sw01:4,10
            break
    if e_D_sum < EDS and m_D_sum < MDS and e_D_sum != 0 and m_D_sum != 0:
        save_path_N = os.path.join(save_path, "NULL_Rough_screening_results")
        file_name_N = os.path.join(save_path_N, f'file_a_{a}_b_{b}.txt')
        np.savetxt(file_name_N, cells_data_ALS_no0)
        np.set_printoptions(suppress=True)
        print(e_D_sum)
        print(m_D_sum)
        return file_name_N