import numpy as np

# 定义旋转角度（弧度）
theta = np.pi * (-129-117)/360  # 45 度

# 定义旋转轴
axis = np.array([0, 0, 1])  # 绕 z 轴旋转

# 生成旋转矩阵
def rotation_matrix(axis, theta):
    """
    返回绕给定轴旋转给定角度的旋转矩阵
    """
    axis = axis / np.linalg.norm(axis)  # 归一化旋转轴
    a = np.cos(theta / 2)
    b, c, d = -axis * np.sin(theta / 2)
    return np.array([
        [a*a + b*b - c*c - d*d, 2*(b*c - a*d), 2*(b*d + a*c)],
        [2*(b*c + a*d), a*a + c*c - b*b - d*d, 2*(c*d - a*b)],
        [2*(b*d - a*c), 2*(c*d + a*b), a*a + d*d - b*b - c*c],
    ])

R = rotation_matrix(axis, theta)

# 定义平移向量
t = np.array([6.27434250e+05, 3.25684150e+06, 0])  # 在 x、y、z 方向分别平移 1、2、3 个单位

# 生成移动参数矩阵
T = np.eye(4)
T[:3, :3] = R  # 设置旋转部分
T[:3, 3] = t    # 设置平移部分

# 设置打印选项，输出小数格式而不是科学计数法
np.set_printoptions(suppress=True)

print("移动参数矩阵:")
print(T)