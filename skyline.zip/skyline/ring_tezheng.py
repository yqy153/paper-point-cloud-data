def filter_and_select_columns(input_file, output_file, columns):
    seen = set()
    filtered_lines = []

    with open(input_file, 'r') as infile:
        for line in infile:
            # Split the line by whitespace
            parts = line.split()
            first_column_value = parts[0]

            if first_column_value not in seen:
                seen.add(first_column_value)
                # Select only the specified columns
                selected_columns = [parts[i-1] for i in columns]
                filtered_lines.append(" ".join(selected_columns))

    with open(output_file, 'w') as outfile:
        for line in filtered_lines:
            outfile.write(line + "\n")

# 使用示例
input_file = 'D:/AAAYJS/DATA/Intermediate_data_sw07/chazhi/ALS_filter_Visualization/file_a_627505.80603_b_3256873.825012.txt'  # 输入的txt文件路径
output_file = 'D:/AAAYJS/DATA/Intermediate_data_sw07/chazhi/ring_tezheng_file_a_627505.80603_b_3256873.825012.txt'  # 输出的txt文件路径
columns = [1, 7, 9, 10, 11]  # 要保留的列的索引（1基索引）
filter_and_select_columns(input_file, output_file, columns)

