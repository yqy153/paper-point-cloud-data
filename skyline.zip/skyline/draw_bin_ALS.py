import laspy
import numpy as np
import matplotlib.pyplot as plt

def draw_bin(ALS_file,center_x, center_y, num_rings, num_sectors, r, saomiao_h):
    # 读取 TXT 文件
    in_file = np.loadtxt(ALS_file, dtype=float, comments='//')

    # 读取坐标数据
    x = in_file[:, 0]
    y = in_file[:, 1]
    z = in_file[:, 2]
    zgyh = in_file[:, 3]
    zgyh[zgyh > 50] = 0

    # 指定圆心点 P 的坐标
    a = center_x  # 圆心点 P 的 x 坐标
    b = center_y  # 圆心点 P 的 y 坐标
    c = 0  # 圆心点 P 的 z 坐标

    # 计算每个点到圆心点 P 的距离
    distances = np.sqrt((x - a) ** 2 + (y - b) ** 2)

    # 计算每个点的角度
    angles = np.arctan2(y - b, x - a)

    # 将角度映射到[0, 2*pi)范围内
    angles = np.mod(angles, 2 * np.pi)

    # 将角度和对应的点的信息进行排序
    indices_to_keep = np.where(distances <= r)
    sorted_indices = np.argsort(distances[indices_to_keep])
    sorted_angles = angles[indices_to_keep][sorted_indices]
    sorted_x = x[indices_to_keep][sorted_indices]
    sorted_y = y[indices_to_keep][sorted_indices]
    sorted_z = z[indices_to_keep][sorted_indices]
    sorted_distance = distances[indices_to_keep][sorted_indices]
    sorted_zgyh = zgyh[indices_to_keep][sorted_indices]

    # 遍历每个点将其分到360(水平角)*ring的网格中
    cell_index_ring = np.zeros((len(sorted_x), 1))
    cell_index_sector = np.zeros((len(sorted_x), 1))
    for i in range(len(sorted_x)):
        angle = sorted_angles[i]
        distance = sorted_distance[i]

        # 判断点所在的圆环索引
        per_ring_gap = r / (num_rings + 1)
        ring_gap_index = int(distance / per_ring_gap)
        cell_index_ring[i] = ring_gap_index
        # 计算当前点所属的水平角索引
        angle_per_sector_h = 2 * np.pi / num_sectors
        horizontal_angle_index = int((angle - np.pi / 2) / angle_per_sector_h) % num_sectors
        cell_index_sector[i] = horizontal_angle_index

    point_sorted = np.column_stack((sorted_x, sorted_y, sorted_z, sorted_zgyh, sorted_angles,
                                        sorted_distance, cell_index_ring, cell_index_sector))
    # np.savetxt('D:/AAAYJS/DATA/Intermediate_data/TLS_filter_Visualization/TLS_point_sorted.txt',point_sorted)
    # # 按照圆环进行排序
    # r_x = point_sorted[:, 0]
    # r_y = point_sorted[:, 1]
    # r_z = point_sorted[:, 2]
    # r_zgyh = point_sorted[:, 3]
    # r_ring = point_sorted[:, 6]
    # r_sector = point_sorted[:, 7]
    # ring_sorted_indices = np.argsort(r_ring)
    # ring_sorted_x = r_x[ring_sorted_indices]
    # ring_sorted_y = r_y[ring_sorted_indices]
    # ring_sorted_z = r_z[ring_sorted_indices]
    # ring_sorted_zgyh = r_zgyh[ring_sorted_indices]
    # ring_sorted_ring = r_zgyh[ring_sorted_indices]
    # ring_sorted_sector = r_sector[ring_sorted_indices]
    # null_num = np.zeros((num_sectors * num_rings))
    # coordinates_matrix_sorted = np.column_stack((ring_sorted_ring, ring_sorted_sector, ring_sorted_z, ring_sorted_zgyh,
    #                                       ring_sorted_x, ring_sorted_y, null_num))
    # # 提取前两列相同的行
    # unique_rows, unique_indices = np.unique(coordinates_matrix_sorted[:, :2], axis=0, return_index=True)
    # # 找到每组相同的行中 ring_sorted_z 最大的行的索引
    # max_z_indices = np.argmax(coordinates_matrix_sorted[:, 2], axis=0)
    # # 保留最大的行
    # coordinates_matrix = coordinates_matrix_sorted[unique_indices[max_z_indices]]
    # 将所有点分到不同的圆环和扇区
    num_points = point_sorted.shape[0] # 筛选后剩余的点数（行数）

    # 生成num_rings*num_sectors大小的网格，并对网格赋值
    column1 = np.repeat(np.arange(num_rings), num_sectors) # column1: [0 0 0 0 1 1 1 1 2 2 2 2] column2: [0 1 2 3 0 1 2 3 0 1 2 3]
    column2 = np.tile(np.arange(num_sectors), num_rings)
    z = np.zeros((num_sectors*num_rings))
    zgyh = np.zeros((num_sectors * num_rings))
    null_num = np.zeros((num_sectors * num_rings))
    x = np.zeros((num_sectors * num_rings))
    y = np.zeros((num_sectors * num_rings))
    coordinates_matrix = np.column_stack((column1, column2, z, zgyh, x, y, null_num))  # 创建一个矩阵来存储坐标信息
    # 每个仓只保留最高点
    for n in range(num_points):
        ring_index = int(point_sorted[n, -2])
        sector_index = int(point_sorted[n, -1])
        zgyh = point_sorted[n, 3]
        z = point_sorted[n, 2]
        x_n = point_sorted[n, 0]
        y_n = point_sorted[n, 1]


        # 更新对应位置的值
        matching_indices = np.where(
            (coordinates_matrix[:, 0] == ring_index) & (coordinates_matrix[:, 1] == sector_index))
        if z > coordinates_matrix[matching_indices[0], 2]:
            coordinates_matrix[matching_indices[0], 2] = z
            coordinates_matrix[matching_indices[0], 3] = zgyh
            coordinates_matrix[matching_indices[0], 4] = x_n
            coordinates_matrix[matching_indices[0], 5] = y_n

    for j in range(0, num_rings+1):
        select_rows = coordinates_matrix[coordinates_matrix[:, 0] == j]

        # 统计空仓数量
        count_zeros = np.count_nonzero(select_rows[:, 3] == 0)
        coordinates_matrix[coordinates_matrix[:, 0] == j, 6] = count_zeros

    # 设置扫描仪的高度，计算仰角
    elevation_angles_i = np.zeros((num_rings*num_sectors, 1))
    result_matrix = np.column_stack((coordinates_matrix, elevation_angles_i))
    scanner = saomiao_h+1.5
    for c in range(len(coordinates_matrix)):
        if coordinates_matrix[c, 4] != 0 and coordinates_matrix[c, 5] != 0:
            x_e = coordinates_matrix[c, 4]
            y_e = coordinates_matrix[c, 5]
            z_e = coordinates_matrix[c, 2]
            # 计算每个仓的仰角
            v = np.array([x_e-a, y_e-b, z_e-scanner])
            u = np.array([0, 0, -scanner])
            elevation_angles = np.arccos(np.dot(v, u) / (np.linalg.norm(v) * np.linalg.norm(u)))
            result_matrix[c, 7] = elevation_angles
    # 根据仰角筛选最高可视点
    for m in range(num_sectors):
        result_matrix_sec = result_matrix[result_matrix[:, 1] == m]
        sorted_indices_result = np.array(sorted(result_matrix_sec, key=lambda row: row[0]))
        for ri in range(1, num_rings):
            if sorted_indices_result[ri, 7] <= sorted_indices_result[ri-1, 7]:
                result_matrix[(result_matrix[:, 1] == m) & (result_matrix[:, 0] == ri), 2] = -1000
    # 添加属性
    zero_array = np.zeros((num_rings*num_sectors, 3))
    coordinates_matrix_result = np.concatenate((np.array(result_matrix), zero_array), axis=1)
    for rin in range(0, num_rings):
        select_rows = coordinates_matrix_result[coordinates_matrix_result[:, 0] == rin]
        std_deviation = 0
        max_value = 0
        mean_deviation = 0
        # 计算空仓比例
        count_zeros = np.count_nonzero(select_rows[:, 2] == 0)+np.count_nonzero(select_rows[:, 2] == -1000)
        # 使用 np.max() 计算第四列（归一化高程）的最大值
        max_value = np.max(select_rows[:, 3])
        if count_zeros <= 90:
            # 计算第四列（归一化高程）的标准差
            std_deviation = np.std(select_rows[select_rows[:, 3] != 0, 3])
            # 计算第四列（归一化高程）的平均高程
            mean_deviation = np.mean(select_rows[select_rows[:, 3] != 0, 3])
        coordinates_matrix_result[coordinates_matrix_result[:, 0] == rin, 6] = count_zeros
        coordinates_matrix_result[coordinates_matrix_result[:, 0] == rin, 8] = std_deviation
        coordinates_matrix_result[coordinates_matrix_result[:, 0] == rin, 9] = max_value
        coordinates_matrix_result[coordinates_matrix_result[:, 0] == rin, 10] = mean_deviation
    # 利用前后插值填充空仓，让后续仓的差值计算更稳定
    zero_or_minus1000_indices = np.where((coordinates_matrix_result[:, 2] == 0) | (coordinates_matrix_result[:, 2] == -1000))[0]
    for idx in zero_or_minus1000_indices:
        current_value = coordinates_matrix_result[idx, 0]

        # 找到第一列小于当前值的行，并且第三列不等于0且不等于-1000
        potential_replacement_indices = np.where((coordinates_matrix_result[:, 1] == coordinates_matrix_result[idx, 1])
                                                 & (coordinates_matrix_result[:, 0] < current_value)
                                                 & (coordinates_matrix_result[:, 2] != 0)
                                                 & (coordinates_matrix_result[:, 2] != -1000))[0]

        if len(potential_replacement_indices) > 0:
            min_diff_index = np.argmin(np.abs(current_value - coordinates_matrix_result[potential_replacement_indices, 0]))
            replacement_value = coordinates_matrix_result[potential_replacement_indices[min_diff_index], 2]
            replacement_value_zgyh =  coordinates_matrix_result[potential_replacement_indices[min_diff_index], 3]
            coordinates_matrix_result[idx, 2] = replacement_value
            coordinates_matrix_result[idx, 3] = replacement_value_zgyh


    return coordinates_matrix_result