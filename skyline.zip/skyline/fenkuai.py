import laspy
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def point_block(TLS_file, center_x, center_y):
    # 读取 LAS 文件
    TLS_in_file = np.loadtxt(TLS_file, dtype=float, comments='//')

    # 读取坐标数据
    x_TLS = TLS_in_file[:, 0]
    y_TLS = TLS_in_file[:, 1]
    z_TLS = TLS_in_file[:, 2]

    # 指定圆心点 P 的坐标
    a = center_x  # 圆心点 P 的 x 坐标
    b = center_y  # 圆心点 P 的 y 坐标
    c = 0  # 圆心点 P 的 z 坐标

    # 计算每个点到圆心点 P 的距离
    distances = np.sqrt((x_TLS - a) ** 2 + (y_TLS - b) ** 2)
    # 过滤距离大于50的点
    mask = distances <= 50
    filtered_x_TLS = x_TLS[mask]
    filtered_y_TLS = y_TLS[mask]
    filtered_z_TLS = z_TLS[mask]

    # 组合成新的矩阵
    filtered_matrix = np.column_stack((filtered_x_TLS, filtered_y_TLS, filtered_z_TLS))

    return filtered_matrix, 50
