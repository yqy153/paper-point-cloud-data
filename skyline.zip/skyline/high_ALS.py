import numpy as np
def high_ALS(ALS_file):
    # 读取文本数据
    txt_file_path = ALS_file

    # 使用loadtxt函数加载数据
    point_cloud_data = np.loadtxt(txt_file_path, delimiter=' ')
    # 定义网格参数
    grid_size = 0.5
    grid_min = np.min(point_cloud_data[:, :2], axis=0)
    grid_max = np.max(point_cloud_data[:, :2], axis=0)
    grid_dims = np.ceil((grid_max - grid_min) / grid_size).astype(int)

    # 为每个点创建网格索引
    grid_indices = np.floor((point_cloud_data[:, :2] - grid_min) / grid_size).astype(int)
    grid_indices = np.clip(grid_indices, [0, 0], grid_dims - 1)  # 限制索引在网格范围内

    # 创建一个空的网格来存储最高z值
    max_z_grid = np.full(grid_dims, -np.inf)
    max_xy_grid = np.empty((grid_dims[0], grid_dims[1], 3))

    # 填充网格的最大z值和最高点的xy坐标
    for i in range(point_cloud_data.shape[0]):
        x = point_cloud_data[i, 0]
        y = point_cloud_data[i, 1]
        zgyh = point_cloud_data[i, 3]
        z = point_cloud_data[i, 2]
        grid_x, grid_y = grid_indices[i]
        if z > max_z_grid[grid_x, grid_y]:
            max_z_grid[grid_x, grid_y] = z
            max_xy_grid[grid_x, grid_y] = [x, y, zgyh]
    filtered_point_cloud = []
    # 打印最终结果
    for x in range(grid_dims[0]):
        for y in range(grid_dims[1]):
            if max_z_grid[x, y] != -np.inf:
                max_x, max_y, zgyh = max_xy_grid[x, y]
                max_z = max_z_grid[x, y]
                filtered_point_cloud.append([max_x, max_y, max_z, zgyh])

    return filtered_point_cloud
