import numpy as np
import os
# 配准函数
def registration(cells_data_ALS, cells_data_TLS, num_sectors, ring, a, b,save_path, angle):
    # 初始化平均值
    diff_per_ring_mean = []
    diff_per_mean = 0
    # 根据手机数据限制匹配角度
    sector_threshold = round((angle / 360) * (2 * np.pi) / (2 * np.pi / num_sectors))
    # 初始化每个圆环内的高程值
    i = ring
    # matched_value_count = 0
    for k in range(num_sectors):
        diff_per_ring = []
        matched_value_count = 0
        for j in range(sector_threshold-20, sector_threshold+20):
            matching_indices_ALS = np.where((cells_data_ALS[:, 0] == ring+1) & (cells_data_ALS[:, 1] == j))
            sector_ALS = cells_data_ALS[matching_indices_ALS[0], 1]
            z_ALS = cells_data_ALS[matching_indices_ALS[0], 3]
            sector_shift = k + sector_ALS
            if sector_shift.size != 0:
                if (cells_data_TLS[:, 1] == sector_shift).any():
                    matching_indices_TLS = np.where((cells_data_TLS[:, 0] == ring+1) & (cells_data_TLS[:, 1] == sector_shift))
                    z_TLS = cells_data_TLS[matching_indices_TLS[0], 3]
                    if z_TLS != 0 and z_ALS != 0:
                        matched_value_count += 1
                        difference_sum = np.abs(z_ALS - z_TLS) # 这只是找到了一个仓的差值
                        diff_per_ring.append([i, j, difference_sum])
                else:
                    if sector_shift > num_sectors:
                        if (cells_data_TLS[:, 1] == (sector_shift - num_sectors)).any():
                            # matched_value_count += 1
                            matching_indices_TLS = np.where((cells_data_TLS[:, 0] == i+1) & (cells_data_TLS[:, 1] == (sector_shift-num_sectors)))
                            if z_TLS != 0 and z_ALS != 0:
                                matched_value_count += 1
                                z_TLS = cells_data_TLS[matching_indices_TLS[0], 3]
                                difference_sum = np.abs(z_ALS - z_TLS)
                                diff_per_ring.append([i, j, difference_sum])

        if matched_value_count > 20:
            diff_per_ring_sum = np.sum(diff_per_ring)/ring # 根据圆环数对每个                                                                                                                                                  圆环的高程差值之和进行加权
            diff_per_mean = diff_per_ring_sum/matched_value_count
            diff_per_ring_mean.append([i, k, diff_per_mean])
            save_path_k = os.path.join(save_path, "xuanzhuan/xuanzhuan_k/")
            file_name_k = os.path.join(save_path_k, f'file_i_{i}_k_{k}_sum_{diff_per_ring_sum}_mean_{diff_per_mean}.txt')
            np.savetxt(file_name_k, diff_per_ring)
    # if a == 627477.637042 and b == 3256909.251210:
    #     # 将此处ALS圆环储存
    #     cells_data_ring_als = cells_data_ALS[cells_data_ALS[:, 0] == ring]
    #     save_path_als = 'D:/AAAYJS/DATA/Intermediate_data_sw07/xuanzhuan/xuanzhuan_als/'
    #     file_name_als = os.path.join(save_path_als, f'file_{i}.txt')
    #     np.savetxt(file_name_als, cells_data_ring_als)
    #     # 将此处TLS圆环储存
    #     cells_data_ring_tls = cells_data_TLS[cells_data_TLS[:, 0] == ring]
    #     save_path_tls = 'D:/AAAYJS/DATA/Intermediate_data_sw07/xuanzhuan/xuanzhuan_tls/'
    #     file_name_tls = os.path.join(save_path_tls, f'file_{i}.txt')
    #     np.savetxt(file_name_tls, cells_data_ring_tls)
    # save_path = 'D:/AAAYJS/DATA/Intermediate_data/registration/'
    # file_name = os.path.join(save_path, f'file_a_{a}_b_{b}.txt')
    # np.savetxt(file_name, diff_per_ring_mean)
    # 每一个圆环有60个结果
    # 最小值的行,将差值为0改为1000
    # matrix_without_zeros = np.where(diff_per_ring[:, 2] == 0, 1000, diff_per_ring[:, 2])
    # min_index = np.argmin(matrix_without_zeros)
    # # 找到每次移动后旋转的最小值
    # min_value = matrix_without_zeros[min_index]
    # min_index_ring[i+1, 0] = min_index
    # min_index_ring[i+1, 1] = min_value
    return diff_per_ring_mean