def filter_point_cloud(input_file, output_file, x1, y1, z1, threshold):
    """
    过滤点云文件中的点，保留与指定点p(x1, y1, z1)的x y值相差不大于阈值的点。

    参数:
    input_file (str): 输入点云文件路径
    output_file (str): 输出筛选后点云文件路径
    x1, y1, z1 (float): 指定的点p的坐标
    threshold (float): x y值允许的最大差异，默认为30
    """
    with open(input_file, 'r') as file:
        lines = file.readlines()

    filtered_points = []
    for line in lines:
        x, y, z = map(float, line.strip().split()[:3])
        if abs(x - x1) <= threshold and abs(y - y1) <= threshold:
            filtered_points.append(line)

    with open(output_file, 'w') as file:
        file.writelines(filtered_points)


# 示例使用
input_file = 'D:/AAAYJS/DATA/ALS_G/ALS_shouchi_gp.txt'  # 输入文件路径
output_file = 'D:/AAAYJS/DATA/ALS_G/151013_gp.txt'  # 输出文件路径
x1, y1, z1 = 627311.6816618342, 3257276.9931784146, 352  # 指定点p的坐标

filter_point_cloud(input_file, output_file, x1, y1, z1, 30)
