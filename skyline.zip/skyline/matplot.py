import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 读取点云数据
def read_point_cloud(file_path):
    points = np.loadtxt(file_path, skiprows=2)
    return points

# 根据 Z 值生成颜色
def generate_colors(points):
    z_min = np.min(points[:, 2])
    z_max = np.max(points[:, 2])
    colors = (points[:, 2] - z_min) / (z_max - z_min)  # 根据 Z 值归一化生成颜色
    return colors

# 可视化点云
def visualize_point_cloud(points, colors):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    ax.scatter(points[:, 0], points[:, 1], points[:, 2], c=colors, cmap='viridis')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    # 添加颜色图例
    norm = plt.Normalize(colors.min(), colors.max())
    sm = plt.cm.ScalarMappable(cmap='viridis', norm=norm)
    sm.set_array([])
    fig.colorbar(sm, label='Z Value')

    plt.show()

if __name__ == "__main__":
    file_path = "I:/AAAYJS/Data/txt_data/0331-1_save.txt"  # 你的点云文件路径
    points = read_point_cloud(file_path)
    colors = generate_colors(points)
    visualize_point_cloud(points, colors)
