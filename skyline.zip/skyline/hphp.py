import numpy as np
import draw_bin_ALS
import os
import null_deta
import registration
import time

def hphp(save_path, gf, x, y, nr, ns, EDS, MDS, angle):
    # 选取候选区域函数
    def center_CA(center_initial_x, center_initial_y, ground_file, r):
        ground_file = np.loadtxt(ground_file, dtype=float, comments='//')
        filtered_rows = ground_file[(center_initial_x-r < ground_file[:, 0]) & (ground_file[:, 0] < center_initial_x+r)
                                    & (center_initial_y-r < ground_file[:, 1]) & (ground_file[:, 1] < center_initial_y+r)]
        file_save = os.path.join(save_path, "ground_center/center_candidate.txt")
        np.savetxt(file_save, filtered_rows, fmt='%f', delimiter='\t')
        return file_save

    intial_center_x = x
    intial_center_y = y
    num_rings = nr
    num_sectors = ns
    r = 0
    ALS_sample_high_r = np.loadtxt(os.path.join(save_path, "_high_ALS/_high_ALS.txt"), dtype=float, comments='//')
    x_h = ALS_sample_high_r[:, 0]
    y_h = ALS_sample_high_r[:, 1]
    r_max = 50
    cells_data_TLS_no0 = np.loadtxt(os.path.join(save_path, "chazhi/HLS_filter/HLS_filter.txt"))

    # 地面候选点选取
    ground_file = gf
    center_file = np.loadtxt(center_CA(intial_center_x, intial_center_y, ground_file, 30))
    # 创建一个空字典
    my_dict = {}
    start_time = time.time()
    # 遍历每个候选点
    for i in range(len(center_file)-1):
        # 初始化
        all_index_sector = []
        all_index_sector_ = []
        ring_null_num = 0
        ring_null_delta_num = 0
        columns1 = []
        columns2 = []
        center_x = center_file[i, 0]
        center_y = center_file[i, 1]
        # 机载分块
        # 指定圆心点 P 的坐标
        a = center_x  # 圆心点 P 的 x 坐标
        b = center_y  # 圆心点 P 的 y 坐标
        c = 0  # 圆心点 P 的 z 坐标

        # 计算每个点到圆心点 P 的距离
        distances = np.sqrt((x_h - a) ** 2 + (y_h - b) ** 2)
        # 点云分块
        ALS_sample_high_b = ALS_sample_high_r[distances <= r_max]
        save_path_als = os.path.join(save_path, "ALS_block")
        file_name_als = os.path.join(save_path_als, f'file_a_{a}_b_{b}.txt')
        np.savetxt(file_name_als, ALS_sample_high_b)
        in_file___ = np.loadtxt(file_name_als, dtype=float, comments='//')
        if in_file___.ndim > 1:
            # 点云分仓
            cells_data_ALS = draw_bin_ALS.draw_bin(file_name_als, center_x, center_y,
                                                   num_rings, num_sectors, r_max, 357)  # 圆环、扇区、z、zgyh、x y null_num、仰角、高程标准差、最大高程
            cells_data_ALS = np.array(cells_data_ALS)
            # 把圆环最内圈的数据删除
            cells_data_ALS_no0 = cells_data_ALS[cells_data_ALS[:, 0] != 0]
            save_path_f = os.path.join(save_path, "chazhi/ALS_filter")
            file_name_f = os.path.join(save_path_f, f'file_a_{a}_b_{b}.txt')
            np.savetxt(file_name_f, cells_data_ALS_no0)


            # 用于可视化,把x,y和归一化高程处为0的点都删除
            cells_data_ALS_z0 = cells_data_ALS_no0[cells_data_ALS_no0[:, 2] != 0]
            # # 把仰角为-1000的点都删除
            cells_data_ALS_e0 = cells_data_ALS_z0[cells_data_ALS_z0[:, 2] != -1000]
            cells_data_ALS_x0 = cells_data_ALS_e0[cells_data_ALS_e0[:, 4] != 0]
            cells_data_ALS_y0 = cells_data_ALS_x0[cells_data_ALS_x0[:, 5] != 0]
            save_path_V = os.path.join(save_path, "chazhi/ALS_filter_Visualization")
            file_name_V = os.path.join(save_path_V, f'file_a_{a}_b_{b}.txt')
            np.savetxt(file_name_V, cells_data_ALS_y0)
            # # 计算邻近点高差
            # ALS_adjacent = Adjacent_height_difference.get_evaluation(file_name)
            # save_path_AA = 'D:/AAAYJS/DATA/Intermediate_data/ALS_Adjacent/'
            # file_name_AA = os.path.join(save_path_AA, f'file_a_{a}_b_{b}.txt')



            # 粗筛
            TLS = np.loadtxt(os.path.join(save_path, "chazhi/HLS_filter/HLS_filter.txt"),
                                            dtype=float, comments='//')
            # 生成地基的圆环特征
            # diff_yh_TLS = np.zeros((20, 5))
            # diff_yh_file_TLS = TLS
            # for tr in range(1, 20):
            #     diff_yh_TLS[tr - 1, 0] = diff_yh_file_TLS[diff_yh_file_TLS[:, 0] == tr][1, 0]
            #     diff_yh_TLS[tr - 1, 1] = diff_yh_file_TLS[diff_yh_file_TLS[:, 0] == tr][1, 6] # 空仓比例
            #     diff_yh_TLS[tr - 1, 2] = diff_yh_file_TLS[diff_yh_file_TLS[:, 0] == tr][1, 8] # 高程标准差
            #     diff_yh_TLS[tr - 1, 3] = diff_yh_file_TLS[diff_yh_file_TLS[:, 0] == tr][1, 9] # 最大高程
            #     diff_yh_TLS[tr - 1, 4] = diff_yh_file_TLS[diff_yh_file_TLS[:, 0] == tr][1, 10] # 平均高程
            # save_path_dyh = 'D:/AAAYJS/DATA/Intermediate_data_sw07/TLS_tezheng/'
            # file_name_dyh = os.path.join(save_path_dyh, f'TLS_tezheng.txt')
            # np.savetxt(file_name_dyh, diff_yh_TLS)

            ALS = np.loadtxt(file_name_f, dtype=float, comments='//')
            N_D_sum = 0 # 空仓差值之和
            E_D_sum = 0
            M_D_sum = 0
            N = 0 # 匹配不上的圆环个数
            E = 0
            M = 0
            # ALS_cushai = null_deta.null_deta(TLS, ALS, a, b, cells_data_ALS_no0)
            ALS_cushai = null_deta.null_deta(TLS, ALS, a, b, cells_data_ALS_no0, save_path, EDS, MDS)
            # ALS_cushai = ME_deta.null_deta(TLS, ALS, a, b)

            # 配准函数
            if ALS_cushai != None:
                # 圆环特征
                diff_yh_ALS = np.zeros((num_rings, 5))
                diff_yh_file_ALS = ALS
                for j in range(1, num_rings):
                    diff_yh_ALS[j - 1, 0] = diff_yh_file_ALS[diff_yh_file_ALS[:, 0] == j][1, 0]
                    diff_yh_ALS[j - 1, 1] = diff_yh_file_ALS[diff_yh_file_ALS[:, 0] == j][1, 6] # 空仓比例
                    diff_yh_ALS[j - 1, 2] = diff_yh_file_ALS[diff_yh_file_ALS[:, 0] == j][1, 8] # 高程标准差
                    diff_yh_ALS[j - 1, 3] = diff_yh_file_ALS[diff_yh_file_ALS[:, 0] == j][1, 9] # 最大高程
                    diff_yh_ALS[j - 1, 4] = diff_yh_file_ALS[diff_yh_file_ALS[:, 0] == j][1, 10] # 平均高程
                save_path_dyh = os.path.join(save_path, "all_ring_tezheng/")
                file_name_dyh = os.path.join(save_path_dyh, f'_{a}_{b}.txt')
                np.savetxt(file_name_dyh, diff_yh_ALS)
                # print(ALS_cushai)
                _ALS = np.loadtxt(ALS_cushai, dtype=float, comments='//')
                _TLS = TLS
                effective_ring = 0 # 有效圆环数
                for ring in range(3, (num_rings-1)):
                        # ring_null_delta_num为匹配的圆环数
                    # if _ALS[ring, 4] < 40 and _TLS[ring, 4] < 40:
                    paramters = registration.registration(_ALS, _TLS, num_sectors, ring, a, b, save_path, angle)
                    if paramters != []:
                        paramters_ = np.array([[row[0], row[1], row[2][0]] for row in paramters])
                        # # 保存每个圆环每次偏移后所有圆环的差值之和
                        # save_path_p = 'D:/AAAYJS/DATA/Intermediate_data_sw07/registration_ring_detasum/'
                        # file_name_p = os.path.join(save_path_V, f'file_a_{a}_b_{b}_r_{ring}.txt')
                        # np.savetxt(file_name_p, paramters_)
                        # 得到圆环中不同旋转扇区匹配差值最小的那个
                        min_index_sector = paramters_[np.argmin(paramters_[:, 2]), :]
                        # 将圆环数、扇区数和每个圆环的配准差值添加到all_index_sector中
                        all_index_sector.append(min_index_sector)
                        all_index_sector_ = np.array([row.tolist() for row in all_index_sector])
                        # effective_ring += 1

                # 用其他圆环检验最小值所在圆环
                if all_index_sector_ != []:
                    min_index_center = center_file[i, :]
                    min_index = all_index_sector_[np.argmin(all_index_sector_[:, 2]), :]
                    # 将同一点下所有圆环的高差最小值处对应的扇区数带入其他圆环求总差值
                    sector_mate = min_index[1]
                    cells_data_ALS_no0[:, 1] += sector_mate
                    cells_data_ALS_no0[:, 1][cells_data_ALS_no0[:, 1] > 120] -= 120
                    null_num = np.sum(cells_data_ALS_no0[:, 7])
                    # 找到第一列和第二列都相同的行的索引
                    # 获取两个数组的前两列（圆环数和扇区数）
                    columns1 = cells_data_ALS_no0[:, :2]
                    columns2 = cells_data_TLS_no0[:, :2]
                    # 使用NumPy的 broadcasting 比较前两列是否相等
                    matching_indices = np.where(np.all(columns1[:, None, :] == columns2, axis=2))
                    # 获取相等行的第3列值并相减（高程差值）
                    matching_rows_diff = np.abs(cells_data_ALS_no0[matching_indices[0], 3] -
                                                cells_data_TLS_no0[matching_indices[1], 3])
                    # 计算第三列的绝对差值之和
                    abs_diff_sum = np.sum(matching_rows_diff)
                    abs_diff_mean = abs_diff_sum/(num_rings*num_sectors - null_num/num_sectors-num_sectors)
                    #print(abs_diff_sum)
                    if abs_diff_mean < 10:
                        print(abs_diff_mean)
                        print(min_index_center.astype(float))
                        print(min_index.astype(float))
                        # 创建一个空字典
                        my_dict[abs_diff_mean] = [min_index_center.astype(float), min_index.astype(float)]
                    min_index_center = []
                    min_index = []
    end_time = time.time()
    elapsed_time = end_time - start_time

    print(f"代码执行时间: {elapsed_time} 秒")
    # 找到字典中键最小的2个
    sorted_items = sorted(my_dict.items(), key=lambda x: x[0])[:2]
    # save_path_result = os.path.join(save_path, f'daima_result.txt')
    # np.savetxt(save_path_result, sorted_items)

    # 输出结果
    np.set_printoptions(suppress=True)
    for key, value in sorted_items:
        print(f'{key}: {value}')





