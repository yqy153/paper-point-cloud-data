import numpy as np


def calculate_rmse(diff_values):
    """Calculate RMSE for a given list of differences."""
    squared_diffs = np.square(diff_values)
    mse = np.mean(squared_diffs)
    rmse = np.sqrt(mse)
    return rmse


def main(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    for line in lines:
        # Split the line into x, y, z differences and convert to floats
        diff_values = list(map(float, line.strip().split()))

        # Ensure there are exactly 3 values per line
        if len(diff_values) == 3:
            rmse = calculate_rmse(diff_values)
            print(f"RMSE for {diff_values}: {rmse:.4f}")
        else:
            print(f"Invalid data on line: {line.strip()}")


if __name__ == "__main__":
    file_path = 'D:/AAAYJS/DATA/RMSE.txt'  # Replace with your txt file path
    main(file_path)
