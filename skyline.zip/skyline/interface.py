from PyQt5.QtWidgets import QApplication, QLabel, QLineEdit, QPushButton, QHBoxLayout, QVBoxLayout, QWidget, QComboBox, QFileDialog
from PyQt5.QtCore import Qt
import hphp0
import hphp
import subprocess

def on_file_button_click(file_entry):
    file_path, _ = QFileDialog.getOpenFileName(window, "选择文件", "", "All Files (*);;Text Files (*.txt)")
    file_entry.setText(file_path)

def on_save_button_click(file_entry):
    # Specify the default directory for saving files
    default_directory = "D:/AAAYJS/DATA/"
    folder_path = QFileDialog.getExistingDirectory(window, "选择文件夹", default_directory)
    file_entry.setText(folder_path)

def OK_button_click():
    Ring_Number = int(combo_box_rings.currentText())
    Sector_Number = int(combo_box_sectors.currentText())
    TLS_UG = TLS_UG_entry.text()
    TLS_UGN = TLS_UGN_entry.text()
    ALS_UG = ALS_UG_entry.text()
    ALS_UGN = ALS_UGN_entry.text()
    X = float(X_entry.text())
    Y = float(Y_entry.text())
    save_path = save_entry.text()
    ground_file = ALS_G_entry.text()
    ED_SUM = float(ED_SUM_entry.text())
    MD_SUM = float(MD_SUM_entry.text())
    angle = float(angle_entry.text())
    hphp0.hphp0(TLS_UG, TLS_UGN, ALS_UG, ALS_UGN, save_path, X, Y, Ring_Number, Sector_Number)
    hphp.hphp(save_path, ground_file, X, Y, Ring_Number, Sector_Number, ED_SUM, MD_SUM, angle)
    app.exit()

def Cancel_button_click():
    app.exit()

app = QApplication([])

window = QWidget()
window.setWindowTitle("Registration")
window.resize(500, 300)

layout = QVBoxLayout()

# 设置圆环和扇区个数
degrees_layout = QHBoxLayout()
label_rings = QLabel("Ring Number:")
degrees_layout.addWidget(label_rings)

combo_box_rings = QComboBox()
combo_box_rings.addItems(["0", "10", "15", "20", "25", "30", "35"])
combo_box_rings.setCurrentIndex(3)  # 设置初始值为10
degrees_layout.addWidget(combo_box_rings)

label_sectors = QLabel("Sector Number:")
degrees_layout.addWidget(label_sectors)

combo_box_sectors = QComboBox()
combo_box_sectors.addItems(["0", "30", "60", "90", "120", "180", "360"])
combo_box_sectors.setCurrentIndex(4)  # 设置初始值为90
degrees_layout.addWidget(combo_box_sectors)

layout.addLayout(degrees_layout)

# 添加文件
TLS_UG_layout = QHBoxLayout()
TLS_UG_label = QLabel("TLS UG:")
TLS_UG_layout.addWidget(TLS_UG_label)

TLS_UG_entry = QLineEdit("D:/AAAYJS/DATA/HLS_UG/154942ug_jiequ_yidonghou.txt")  # 设置默认值
TLS_UG_layout.addWidget(TLS_UG_entry)

TLS_UG_button = QPushButton("...")
TLS_UG_button.clicked.connect(lambda: on_file_button_click(TLS_UG_entry))
TLS_UG_layout.addWidget(TLS_UG_button)

layout.addLayout(TLS_UG_layout)

# TLS非地面点归一化（Normalization）文件
TLS_UGN_layout = QHBoxLayout()
TLS_UGN_label = QLabel("TLS UGN:")
TLS_UGN_layout.addWidget(TLS_UGN_label)

TLS_UGN_entry = QLineEdit("D:/AAAYJS/DATA/HLS_UGN_YDH/154942jiequ.txt")  # 设置默认值
TLS_UGN_layout.addWidget(TLS_UGN_entry)

TLS_UGN_button = QPushButton("...")
TLS_UGN_button.clicked.connect(lambda: on_file_button_click(TLS_UGN_entry))
TLS_UGN_layout.addWidget(TLS_UGN_button)

layout.addLayout(TLS_UGN_layout)

# 添加文件选取，ALS非地面点文件
ALS_UG_layout = QHBoxLayout()
ALS_UG_label = QLabel("ALS UG:")
ALS_UG_layout.addWidget(ALS_UG_label)

ALS_UG_entry = QLineEdit("D:/AAAYJS/DATA/ALS_UG/_all_offground_shouchi.txt")  # 设置默认值
ALS_UG_layout.addWidget(ALS_UG_entry)

ALS_UG_button = QPushButton("...")
ALS_UG_button.clicked.connect(lambda: on_file_button_click(ALS_UG_entry))
ALS_UG_layout.addWidget(ALS_UG_button)

layout.addLayout(ALS_UG_layout)

# 添加文件选取，ALS非地面点归一化（Normalization）文件
ALS_UGN_layout = QHBoxLayout()
ALS_UGN_label = QLabel("ALS UGN:")
ALS_UGN_layout.addWidget(ALS_UGN_label)

ALS_UGN_entry = QLineEdit("D:/AAAYJS/DATA/ALS_UGN/151013.txt")  # 设置默认值
ALS_UGN_layout.addWidget(ALS_UGN_entry)

ALS_UGN_button = QPushButton("...")
ALS_UGN_button.clicked.connect(lambda: on_file_button_click(ALS_UGN_entry))
ALS_UGN_layout.addWidget(ALS_UGN_button)

layout.addLayout(ALS_UGN_layout)

# 添加文件选取，扫描中心候选点文件
ALS_G_layout = QHBoxLayout()
ALS_G_label = QLabel("ALS G:")
ALS_G_layout.addWidget(ALS_G_label)

ALS_G_entry = QLineEdit("D:/AAAYJS/DATA/ALS_G/ALS_shouchi_gp_sample_2.txt")  # 设置默认值
ALS_G_layout.addWidget(ALS_G_entry)

ALS_G_button = QPushButton("...")
ALS_G_button.clicked.connect(lambda: on_file_button_click(ALS_G_entry))
ALS_G_layout.addWidget(ALS_G_button)

layout.addLayout(ALS_G_layout)

# 手机定位定向数据
MPDD_label_layout = QHBoxLayout()
label_MPDD = QLabel("MPDD:")
MPDD_label_layout.addWidget(label_MPDD)

MPDD_layout = QHBoxLayout()
label_X = QLabel("X:")
MPDD_layout.addWidget(label_X)
X_entry = QLineEdit("627394.0074761473")  # 设置默认值
MPDD_layout.addWidget(X_entry)

label_Y = QLabel("Y:")
MPDD_layout.addWidget(label_Y)
Y_entry = QLineEdit("3257154.740957631")  # 设置默认值
MPDD_layout.addWidget(Y_entry)

label_angle = QLabel("angle:")
MPDD_layout.addWidget(label_angle)
angle_entry = QLineEdit("92")  # 设置默认值
MPDD_layout.addWidget(angle_entry)

layout.addLayout(MPDD_layout)

# 文件保存
save_layout = QHBoxLayout()
save_label = QLabel("Save File:")
save_layout.addWidget(save_label)

save_entry = QLineEdit("D:/AAAYJS/DATA/Intermediate_data_154942/")  # 设置默认值
save_layout.addWidget(save_entry)

save_button = QPushButton("...")
save_button.clicked.connect(lambda: on_save_button_click(save_entry))
save_layout.addWidget(save_button)

layout.addLayout(save_layout)

# 粗筛参数设置
CS_label_layout = QHBoxLayout()
label_CS = QLabel("CS:")
MPDD_label_layout.addWidget(label_CS)

CS_layout = QHBoxLayout()
label_ED_SUM = QLabel("ED_SUM:")
CS_layout.addWidget(label_ED_SUM)
ED_SUM_entry = QLineEdit("60")  # 设置默认值
CS_layout.addWidget(ED_SUM_entry)

label_MD_SUM = QLabel("MD_SUM:")
CS_layout.addWidget(label_MD_SUM)
MD_SUM_entry = QLineEdit("60")  # 设置默认值
CS_layout.addWidget(MD_SUM_entry)

layout.addLayout(CS_layout)

# OK和Cancel按钮
OK_layout = QHBoxLayout()
button_OK = QPushButton("OK")
button_OK.clicked.connect(OK_button_click)
button_Cancel = QPushButton("Cancel")
button_Cancel.clicked.connect(Cancel_button_click)
OK_layout.addWidget(button_OK)
OK_layout.addWidget(button_Cancel)

layout.addLayout(OK_layout)

window.setLayout(layout)
window.show()

app.exec_()
