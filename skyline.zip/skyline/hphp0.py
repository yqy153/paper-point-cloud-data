import numpy as np
import draw_bin_ALS
import fenkuai
import high_ALS
import os
import time
def hphp0(TLS, TLSN, ALS, ALSN, save_path, x, y, nr, ns):
    # 初始化
    TLS_file_1 = TLS
    TLS_file_2 = TLSN
    intial_center_x = x
    intial_center_y = y
    num_rings = nr
    num_sectors = ns
    r = 0

    start_time = time.time()
    # 合并归一化前后的Z值，将归一化前后的z值合并到一个文件
    TLS_in_file_1 = np.loadtxt(TLS_file_1, dtype=float, comments='//')
    TLS_in_file_2 = np.loadtxt(TLS_file_2, dtype=float, comments='//')
    T_x = TLS_in_file_2[:, 0]
    T_y = TLS_in_file_2[:, 1]
    T_z1 = TLS_in_file_1[:, 2]
    T_z2 = TLS_in_file_2[:, 2]
    matrix = np.column_stack((T_x, T_y, T_z1, T_z2))
    np.savetxt(os.path.join(save_path, "HLS_z_merge/HLS_z_merge.txt"), matrix, delimiter=' ')
    TLS_file = os.path.join(save_path, "HLS_z_merge/HLS_z_merge.txt")
    end_time = time.time()
    elapsed_time = end_time - start_time

    print(f"代码执行时间: {elapsed_time} 秒")

    # 划分标准网格保留网格内最高点
    filtered_point_cloud_T = high_ALS.high_ALS(TLS_file)
    # 将保留下来的点保存到文本文件
    TLS_sample_high = os.path.join(save_path, "_high_HLS/_high_HLS.txt")
    np.savetxt(TLS_sample_high, filtered_point_cloud_T, delimiter=' ')


    # 点云分块
    # TLS_block, r_max = fenkuai.point_block(TLS_sample_high, intial_center_x, intial_center_y)
    # np.savetxt(os.path.join(save_path, "HLS_block/HLS_BLOCK.txt"), TLS_block)
    # np.savetxt(os.path.join(save_path, "HLS_block/_r_max.txt"), np.array([r_max]))
    cells_data_TLS_initial = draw_bin_ALS.draw_bin(TLS_sample_high, intial_center_x, intial_center_y,
                                               num_rings, num_sectors, 50, 357) # 圆环、扇区、z、zgyh、null_num、仰角、高程标准差、最大高程
    cells_data_TLS_i = np.array(cells_data_TLS_initial)
    # 把圆环最内圈的数据删除
    cells_data_TLS_no0 = cells_data_TLS_i[cells_data_TLS_i[:, 0] != 0]
    np.savetxt(os.path.join(save_path, "chazhi/HLS_filter/HLS_filter.txt"), cells_data_TLS_no0)
    # 用于可视化,把xy为0和归一化高程处为0的点都删除
    cells_data_TLS_z0 = cells_data_TLS_no0[cells_data_TLS_no0[:, 2] != 0]
    cells_data_TLS_e0 = cells_data_TLS_z0[cells_data_TLS_z0[:, 2] != -1000]
    cells_data_TLS_x0 = cells_data_TLS_e0[cells_data_TLS_e0[:, 4] != 0]
    cells_data_TLS_y0 = cells_data_TLS_x0[cells_data_TLS_x0[:, 5] != 0]
    np.savetxt(os.path.join(save_path, "chazhi/HLS_filter_Visualization/HLS_filter_Visualization.txt"), cells_data_TLS_y0)

    # 计算邻近仓的高差
    # TLS_adjacent = Adjacent_height_difference.get_evaluation(
    #     'D:/AAAYJS/DATA/Intermediate_data/TLS_filter/TLS_filter.txt')
    # np.savetxt('D:/AAAYJS/DATA/Intermediate_data/TLS_Adjacent/TLS_Adjacent.txt', TLS_adjacent)



    # 机载过滤

    ALS_file_1 = ALS
    ALS_file_2 = ALSN
    # 合并归一化前后的Z值
    in_file_1 = np.loadtxt(ALS_file_1, dtype=float, comments='//')
    in_file_2 = np.loadtxt(ALS_file_2, dtype=float, comments='//')

    # 读取坐标数据
    A_x = in_file_1[:, 0]
    A_y = in_file_1[:, 1]
    A_z1 = in_file_1[:, 2]
    A_z2 = in_file_2[:, 2]
    matrix = np.column_stack((A_x, A_y, A_z1, A_z2))
    np.savetxt(os.path.join(save_path, "ALS_z_merge/ALS_z_merge.txt"), matrix, delimiter=' ')
    ALS_file = os.path.join(save_path, "ALS_z_merge/ALS_z_merge.txt")
    filtered_point_cloud_A = high_ALS.high_ALS(ALS_file)
    # 将保留下来的点保存到文本文件
    ALS_sample_high = os.path.join(save_path, "_high_ALS/_high_ALS.txt")
    np.savetxt(ALS_sample_high, filtered_point_cloud_A, delimiter=' ')
